import React from 'react';

function Home() {
    return (
        <div>
            <p>home !!</p>
        </div>

    );
}

export default Home;