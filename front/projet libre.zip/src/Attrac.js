import React from 'react';

function Attrac() {
    return (
        <div>
            <p>attraction</p>
        </div>

    );
}

export default Attrac;