import React from 'react';

function Parc() {
    return (
        <div>
            <p>parc</p>
        </div>

    );
}

export default Parc;